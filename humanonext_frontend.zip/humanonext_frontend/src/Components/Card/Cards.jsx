import React from "react"
import {  Card } from "react-bootstrap"
import "./Card.css"
import { data } from "../Body/data"

const Cards = () =>{

        // useEffect(() => {
    //     animateBoxes(); // Trigger animation on component mount
    // }, []);

    

    // // Function to animate each box
    // function animateBoxes() {

    //     const boxes = document.querySelectorAll('.box');

    //     boxes.forEach((box, index) => {
    //         // Delay each box's animation
    //         setTimeout(() => {
    //         box.style.transform = 'translateX(200px)';
    //         }, index * 10); // Adjust timing as needed
    //     });
    // }
    
    return(
            
        <div className="container-fluid ">
            <div className=" card-row row ">
                {data.map((item, index) => (
                    <div key={index} className="col-md-4 mb-4">
                    <Card className="bg-light border p-3" >
                        <img src={item.image} alt="team " className="card-img-top" />
                        <Card.Body>
                        <h2 className="card-title">{item.title}</h2>
                        <div className="card-text card-row">
                            {item.language.map((lang, idx) => (
                            <span key={idx} className="rounded-pill bg-secondary m-1 p-2" style={{ whiteSpace: 'nowrap' }}>{lang}</span>
                            ))}
                        </div>
                        </Card.Body>
                        <div>
                        <h6 className="text-left my-3">{item.subtitle}</h6>
                        <div className="text-left fw-lighter">
                            {item.workList.map((work, idx) => (
                            <span key={idx}>{work}<br /></span>
                            ))}
                        </div>
                        </div>
                        <div className="row m-3">
                        <div className="col-md-6 d-flex justify-content-start align-items-center">
                            <div>
                            {item.profilePic.map((pic, idx) => (
                                <img key={idx} className={`profile profile${idx +1}` } src={pic} alt="a profile pic" />
                            ))}
                            </div>
                        </div>
                        <div className="col-md-6 d-flex justify-content-end align-items-center">
                            <button className="rounded-pill btn btn-warning">Get Details</button>
                        </div>
                        </div>
                    </Card>
                    </div>
                ))}
            </div>
        </div>
    )
}

export default Cards