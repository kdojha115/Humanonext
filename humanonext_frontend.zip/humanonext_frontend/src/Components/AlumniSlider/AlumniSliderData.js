export const AlumniSliderData = [
    
    {
        image: "./Image/AlumniImages/1.png",
        title: "GovermentOfIndia"
    },
    {
        image: "./Image/AlumniImages/2.png",
        title: "GovermentOfIndia"
    },
    {
        image: "./Image/AlumniImages/3.png",
        title: "GovermentOfIndia"
    },
    {
        image: "./Image/AlumniImages/4.png",
        title: "GovermentOfIndia"
    },
    {
        image: "./Image/AlumniImages/5.png",
        title: "GovermentOfIndia"
    },
    {
        image: "./Image/AlumniImages/6.png",
        title: "GovermentOfIndia"
    },
    {
        image: "./Image/AlumniImages/7.png",
        title: "GovermentOfIndia"
    },
    {
        image: "./Image/AlumniImages/8.png",
        title: "GovermentOfIndia"
    },
    {
        image: "./Image/AlumniImages/9.png",
        title: "GovermentOfIndia"
    },
    {
        image: "./Image/AlumniImages/10.png",
        title: "GovermentOfIndia"
    },
    {
        image: "./Image/AlumniImages/11.png",
        title: "GovermentOfIndia"
    },
    {
        image: "./Image/AlumniImages/12.png",
        title: "GovermentOfIndia"
    },
    {
        image: "./Image/AlumniImages/13.png",
        title: "GovermentOfIndia"
    },
    {
        image: "./Image/AlumniImages/14.png",
        title: "GovermentOfIndia"
    },
    {
        image: "./Image/AlumniImages/15.png",
        title: "GovermentOfIndia"
    },
    {
        image: "./Image/AlumniImages/16.png",
        title: "GovermentOfIndia"
    },
    {
        image: "./Image/AlumniImages/17.png",
        title: "GovermentOfIndia"
    },
    {
        image: "./Image/AlumniImages/18.png",
        title: "GovermentOfIndia"
    },
    {
        image: "./Image/AlumniImages/19.png",
        title: "GovermentOfIndia"
    },
    {
        image: "./Image/AlumniImages/20.png",
        title: "GovermentOfIndia"
    },
    {
        image: "./Image/AlumniImages/21.png",
        title: "GovermentOfIndia"
    }
    

]