import React from "react";
import './WhyChooseUs.css'

const WhyChooseUs = () =>{
    return (
        <div className="w-100% h-100px m-5 bg-light p-5">
            <div>
                <div className="Heading p-5">
                    <h1>Why Choose Us?</h1>
                </div>
                <p className="Para font-monospace ">We are an expert offshore software development partner, 
                    with over two decades of experience in transforming business processes digitally. 
                    We have often been named as a most preferred software engineering company for
                     our highly collaborative approach</p>
            </div>
            <div className="row mainContainer">
                <div className="Container col w-1px h-80px "> 
                    <div>
                        <h2>Fast Onboarding</h2>
                    </div>
                    <div>
                        <p>We excel at streamlined communication. Enabling rapid application development to our global 
                            clientele with increased proficiency. We make time, culture and location differences imperceptible.</p>
                    </div>
                    <div className="col">
                        <div className="row">Hi</div>
                        <div className="row">Hello</div>
                        <div className="row">Hey</div>
                    </div>
                    <div className="borderDesign"></div>
                </div>
                <div className="Container col  w-1px h-80px ">
                <div>
                        <h2>Fast Onboarding</h2>
                    </div>
                    <div>
                        <p>We excel at streamlined communication. Enabling rapid application development to our global 
                            clientele with increased proficiency. We make time, culture and location differences imperceptible.</p>
                    </div>
                    <div className="borderDesign"></div>
                </div>
                <div className="Container col  w-1px h-80px ">
                <div>
                        <h2>Fast Onboarding</h2>
                    </div>
                    <div>
                        <p>We excel at streamlined communication. Enabling rapid application development to our global 
                            clientele with increased proficiency. We make time, culture and location differences imperceptible.</p>
                    </div>
                    <div className="borderDesign"></div>
                </div>
            </div>
        </div>
    )
}

export default WhyChooseUs